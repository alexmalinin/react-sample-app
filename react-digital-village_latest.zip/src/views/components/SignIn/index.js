import React from "react";

const SignIn = () => <div>Sign in page</div>;

export default SignIn;
