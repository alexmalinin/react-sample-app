import React from "react";

const Dashboard = () => <div>this is dashboard page</div>;

export default Dashboard;
