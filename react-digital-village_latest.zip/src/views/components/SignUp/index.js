import React from "react";

const SignUp = () => <div>Sign up page</div>;

export default SignUp;
