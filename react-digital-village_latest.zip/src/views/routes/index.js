import React from "react";
import { Switch, Route } from "react-router-dom";

import signIn from "./signIn";
import signUp from "./signUp";
import profile from "./profile";
import dashboard from "./dashboard";

export default () => (
  <Switch>
    <Route path="/sign_in" component={signIn} />
    <Route path="/sign_up" component={signUp} />
    <Route path="/profile" component={profile} />
    <Route path="/dashboard" component={dashboard} />
  </Switch>
);
