import React from "react";
import PropTypes from "prop-types";
import { Route } from "react-router-dom";

import HeaderIntro from "@components/HeaderIntro";
import signUp from "@components/SignUp";

import { StyledMainContainer as MainContainer } from "@styled/StyledMainContainer";
import { IntroContainer } from "@styled/StyledContainer";

const SignUpLayout = ({ match }) => (
  <div>
    <HeaderIntro />
    <MainContainer>
      <IntroContainer>
        <Route path={`${match.url}`} component={signUp} />
      </IntroContainer>
    </MainContainer>
  </div>
);

SignUpLayout.propTypes = {
  match: PropTypes.shape({
    url: PropTypes.string.isRequired
  }).isRequired
};

export default SignUpLayout;
