import React from "react";
import PropTypes from "prop-types";
import { Route } from "react-router-dom";

import HeaderBasic from "@components/HeaderBasic";
import { StyledMainContainer as MainContainer } from "@styled/StyledMainContainer";
import SideBarLeft from "@components/SideBarLeft";
import SideBarRight from "@components/SideBarRight";
import Dashboard from "@components/Dashboard";

const DashboardLayout = ({ match }) => (
  <div>
    <HeaderBasic match={match} />
    <MainContainer>
      <SideBarLeft />
      <Route path={`${match.url}`} component={Dashboard} />
      <SideBarRight opened={true} />
    </MainContainer>
  </div>
);

DashboardLayout.propTypes = {
  match: PropTypes.shape({
    url: PropTypes.string.isRequired
  }).isRequired
};

export default DashboardLayout;
