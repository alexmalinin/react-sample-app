// Types

export const CLIENT = "Client";
export const SPECIALIST = "Specialist";

// Roles

export const S_ACTIVE = "active";
export const S_PASSIVE = "passive";
export const S_CORE = "core";
export const S_REDGUY = "red_guy";
export const CUSTOMER = "customer";
