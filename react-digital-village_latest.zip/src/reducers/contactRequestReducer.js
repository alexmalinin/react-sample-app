// export default (state = '', action) => {
//     const { type } = action;
//     switch (type) {
//         case 'CONTACTS':
//             return state;
//         default:
//             return state;
//     }
// };
