const profileInfo = [
  {
    position: "Project Manager",
    company: "Digital Village Pty Ltd",
    period: "Apr 2016: 2 years 9 months",
    from: "Jul 2013",
    to: "Apr 2016",
    summary: "2 years 9 months",
    achievement:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. "
  },
  {
    position: "Lead Developer",
    company: "Digital Village Pty Ltd",
    period: "Apr 2013: 5 years 9 months",
    from: "Jul 2013",
    to: "Apr 2033",
    summary: "1 years 1 months",
    achievement:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore"
  },
  {
    position: "Developer",
    company: "Digital Village Pty Ltd",
    period: "Apr 2010: 1 years 1 months",
    from: "Jul 2013",
    to: "Apr 2033",
    summary: "1 years 1 months",
    achievement:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore"
  }
];

export default profileInfo;
