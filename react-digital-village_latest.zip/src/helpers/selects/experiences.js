export const experiences = [
  { label: "Trainee Developer", value: "Trainee Developer" },
  { label: "Junior Developer", value: "Junior Developer‎" },
  { label: "Middle Developer", value: "Middle Developer" },
  { label: "Senior Developer", value: "Senior Developer" },
  { label: "Main Architector", value: "Main Architector" }
];
