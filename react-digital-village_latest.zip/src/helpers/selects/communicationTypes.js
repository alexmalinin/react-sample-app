export const communicationTypes = [
  "Phone",
  "Email",
  "Slack",
  "WhatsApp",
  "Skype",
  "Person",
  "Other"
];
