export const projectSpecialists = [
  { label: "1-2", value: "1-2" },
  { label: "2-4", value: "2-4" },
  { label: "5-10", value: "5-10" },
  { label: "10+", value: "10+" }
];
