export const signUpUser = [
  { label: "Client", value: "Client" },
  { label: "Specialist", value: "Specialist‎" }
];
