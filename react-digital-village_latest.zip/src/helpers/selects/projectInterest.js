export const projectInterest = [
  {
    label: "Small projects working solo",
    value: "Small projects working solo"
  },
  {
    label: "Contracting in-house as part of a team",
    value: "Contracting in-house as part of a team"
  },
  {
    label: "Joining a Digital Village team and working remotely",
    value: "Joining a Digital Village team and working remotely"
  },
  {
    label:
      "Collaborating with people online and offline to work on large projects.",
    value:
      "Collaborating with people online and offline to work on large projects."
  },
  { label: "Long-term projects", value: "Long-term projects" },
  { label: "Short-term projects", value: "Short-term projects" }
];
