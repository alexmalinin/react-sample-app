export const trueFalse = [
  { label: "Yes", value: true },
  { label: "No", value: false }
];
