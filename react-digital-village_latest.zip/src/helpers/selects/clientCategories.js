export const clientCategories = [
  { label: "Start Up", value: "Start Up" },
  { label: "SME", value: "SME‎" },
  { label: "Agency", value: "Agency" },
  { label: "Enterprise", value: "Enterprise" }
];
