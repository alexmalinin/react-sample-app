export const industries = [
  { label: "Information Technology", value: "IT" },
  { label: "Aviation", value: "Aviation" },
  { label: "Banking", value: "Banking" },
  { label: "Chemical", value: "Chemical" },
  { label: "Clothing", value: "Clothing" },
  { label: "Construction", value: "Construction" },
  { label: "Electronics", value: "Electronics" },
  { label: "Food", value: "Food" },
  { label: "Television", value: "Television" }
];
