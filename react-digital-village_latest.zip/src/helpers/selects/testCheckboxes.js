export const testCheckboxes = [
  "checkbox-1",
  "checkbox-2",
  "checkbox-3",
  "checkbox-4",
  "checkbox-5"
];
