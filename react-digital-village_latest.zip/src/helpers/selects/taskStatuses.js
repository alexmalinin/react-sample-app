export const taskStatuses = [
  { value: 0, text: "Backlog", enum: "backlog" },
  { value: 1, text: "In progress", enum: "in_progress" },
  { value: 2, text: "Done", enum: "done" },
  { value: 3, text: "Accepted", enum: "accepted" }
];
