export const speciality = {
  IT: [
    { label: "React Developer", value: "React Developer" },
    { label: "Node Developer", value: "Node Developer" },
    { label: "Designer", value: "Designer" },
    { label: "Web-Developer", value: "Web-Developer" },
    { label: "QA", value: "QA" },
    { label: "JS Developer", value: "JS Developer" },
    { label: "Angular Developer", value: "Angular Developer" },
    { label: "HTML Coder", value: "HTML Coder" },
    { label: "Front End Developer", value: "Front End Developer" },
    { label: "Back End Developer", value: "Back End Developer" },
    { label: "Ruby Developer", value: "Ruby Developer" }
  ],
  Aviation: [
    { label: "Aviation-Designer", value: "Aviation-Designer" },
    { label: "Aviation-Developer", value: "Aviation-Developer" },
    { label: "Aviation-QA", value: "Aviation-QA" }
  ],
  Banking: [
    { label: "Banking-Designer", value: "Banking-Designer" },
    { label: "Banking-Developer", value: "Banking-Developer" },
    { label: "Banking-QA", value: "Banking-QA" }
  ],

  Chemical: [
    { label: "Chemical-Designer", value: "Chemical-Designer" },
    { label: "Chemical-Developer", value: "Chemical-Developer" },
    { label: "Chemical-QA", value: "Chemical-QA" }
  ],
  Clothing: [
    { label: "Clothing-Designer", value: "Clothing-Designer" },
    { label: "Clothing-Developer", value: "Clothing-Developer" },
    { label: "Clothing-QA", value: "Clothing-QA" }
  ],
  Construction: [
    { label: "Construction-Designer", value: "Construction-Designer" },
    { label: "Construction-Developer", value: "Construction-Developer" },
    { label: "Construction-QA", value: "Construction-QA" }
  ],
  Electronics: [
    { label: "Electronics-Designer", value: "Electronics-Designer" },
    { label: "Electronics-Developer", value: "Electronics-Developer" },
    { label: "Electronics-QA", value: "Electronics-QA" }
  ],
  Food: [
    { label: "Food-Designer", value: "Food-Designer" },
    { label: "Food-Developer", value: "Food-Developer" },
    { label: "Food-QA", value: "Food-QA" }
  ],
  Television: [
    { label: "Television-Designer", value: "Television-Designer" },
    { label: "Television-Developer", value: "Television-Developer" },
    { label: "Television-QA", value: "Television-QA" }
  ]
};
