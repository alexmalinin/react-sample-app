export const remotes = [
  { label: "Remote", value: "Remote" },
  { label: "On-Site", value: "On-Site" },
  { label: "Both", value: "Both" },
  { label: "Unsure", value: "Unsure" },
  { label: "Doesn't matter", value: "Doesn't matter" }
];
