export const employeers = [
  { label: "1 - 5", value: "1 - 5" },
  { label: "5 - 20", value: "5 - 20‎" },
  { label: "20+", value: "20+" }
];
