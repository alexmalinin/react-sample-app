export const job_titles = [
  { label: "Developer", value: "Developer" },
  { label: "Freelancer", value: "Freelancer" },
  { label: "Contractor", value: "Contractor" },
  { label: "Small Business", value: "Small Business" },
  { label: "Agency", value: "Agency" }
];
