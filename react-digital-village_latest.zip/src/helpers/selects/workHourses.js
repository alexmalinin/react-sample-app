export const workHourses = ["0 - 10", "10 - 20", "20 - 30", "40 +"];
