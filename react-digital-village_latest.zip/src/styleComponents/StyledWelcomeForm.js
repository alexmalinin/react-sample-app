import styled from "styled-components";

export default styled.div`
  p {
    margin-bottom: 20px;
  }
`;
