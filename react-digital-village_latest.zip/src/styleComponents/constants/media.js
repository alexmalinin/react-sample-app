const sizes = {
  desktop: 1920,
  tablet: 991,
  phone: 767
};
