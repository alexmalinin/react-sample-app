import reducer from "./reducers";

import * as tasksOperations from "./operations";

export { tasksOperations };

export default reducer;
