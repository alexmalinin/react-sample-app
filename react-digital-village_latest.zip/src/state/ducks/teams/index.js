import reducer from "./reducers";

import * as teamsOperations from "./operations";

export { teamsOperations };

export default reducer;
