import React, { Component } from "react";
import { connect } from "react-redux";
import { Grid } from "semantic-ui-react";
import {
  Container,
  ContainerLarge
} from "../../styleComponents/layout/Container";

class EditProfile extends Component {
  render() {
    return (
      <ContainerLarge>
        {/* <AboutSubHeader /> */}
        <Container indentBot sidebarCondition>
          {/*  */}
        </Container>
      </ContainerLarge>
    );
  }
}

export default EditProfile;
